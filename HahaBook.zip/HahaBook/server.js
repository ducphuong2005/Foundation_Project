const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");
const cors = require("cors");
const session = require("express-session");

const app = express();
const PORT = 3000;

const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth20").Strategy;

// 🔐 Cấu hình Passport + session
app.use(session({
  secret: "hahabook_secret_key",
  resave: false,
  saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());

// 🔑 Passport serialize / deserialize
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

//Google strategy
passport.use(new GoogleStrategy({
  clientID: "342577786043-0tib7anmugc80g8lteockrvhkff7mbd3.apps.googleusercontent.com",
  clientSecret: "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",
  callbackURL: "http://localhost:3000/auth/google/callback" // phải là full URL
}, (accessToken, refreshToken, profile, done) => {
  const user = {
    name: profile.displayName,
    email: profile.emails[0].value,
    avatar: profile.photos[0].value
  };
  done(null, user);
}));



app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

app.use(session({
  secret: "hahabook_secret_key",
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 1000 * 60 * 30 } // 30 phút
}));

// 🧠 Load users từ file
function getUsers() {
  return JSON.parse(fs.readFileSync("users.json", "utf-8"));
}
function saveUsers(users) {
  fs.writeFileSync("users.json", JSON.stringify(users, null, 2));
}

// 🚪 Đăng nhập
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  const users = getUsers();
  const user = users.find(u => u.email === email && u.password === password);
  if (user) {
    req.session.user = { name: user.name, email: user.email };
    res.json({ success: true, name: user.name });
  } else {
    res.json({ success: false, message: "Sai email hoặc mật khẩu!" });
  }
});

// 🆕 Đăng ký
app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;
  let users = getUsers();
  if (users.find(u => u.email === email)) {
    return res.json({ success: false, message: "Email đã tồn tại!" });
  }
  users.push({ name, email, password });
  saveUsers(users);
  res.json({ success: true });
});

// 🔍 Kiểm tra trạng thái login
app.get("/api/check-login", (req, res) => {
  if (req.session.user) res.json({ loggedIn: true, user: req.session.user });
  else res.json({ loggedIn: false });
});

// 📦 Lấy giỏ hàng hiện tại
app.get("/api/cart", (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Chưa đăng nhập" });
  const users = getUsers();
  const user = users.find(u => u.email === req.session.user.email);
  res.json(user ? user.cart || [] : []);
});

// ➕ Thêm sản phẩm vào giỏ
app.post("/api/cart/add", (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Chưa đăng nhập" });
  const { id, name, qty } = req.body;

  let users = getUsers();
  const index = users.findIndex(u => u.email === req.session.user.email);
  if (index === -1) return res.status(404).json({ message: "Không tìm thấy user" });

  const cart = users[index].cart || [];
  const existing = cart.find(p => p.id === id);
  if (existing) existing.qty += qty;
  else cart.push({ id, name, qty });

  users[index].cart = cart;
  saveUsers(users);
  res.json({ success: true, cart });
});

// ❌ Xóa sản phẩm khỏi giỏ
app.post("/api/cart/remove", (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Chưa đăng nhập" });
  const { id } = req.body;

  let users = getUsers();
  const index = users.findIndex(u => u.email === req.session.user.email);
  if (index === -1) return res.status(404).json({ message: "Không tìm thấy user" });

  users[index].cart = (users[index].cart || []).filter(p => p.id !== id);
  saveUsers(users);
  res.json({ success: true, cart: users[index].cart });
});

// 🚀 Khởi động đăng nhập Google
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

// 📩 Google callback
app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/login.html' }),
  (req, res) => {
    req.session.user = req.user; // lưu user vào session
    res.redirect('/home');
  }
);


// 🚪 Đăng xuất
app.get("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});

// 🏠 Trang chủ (bảo vệ)
app.get("/home", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login.html");
  }
  res.sendFile(path.join(__dirname, "public", "home.html"));
});

app.listen(PORT, () => console.log(`Server chạy tại http://localhost:${PORT}`));
