
// =====================================================
// 1) CHECK LOGIN + GẮN THÔNG TIN USER (KỂ CẢ GOOGLE)
// =====================================================
async function loadUser() {
    const res = await fetch('/api/check-login');
    const data = await res.json();

    if (!data.loggedIn) {
        window.location.href = "/login.html";
        return;
    }

    const user = data.user;
    const accountBox = document.querySelector('.account');

    accountBox.innerHTML = `
        <a href="#">${user.name}</a>
        <img src="${user.avatar || 'default.png'}" 
             style="width:35px;height:35px;border-radius:50%;margin-left:8px;">
        <a href="/api/logout" style="padding-left:10px">Logout</a>
    `;
}

// =====================================================
// 2) LOAD SẢN PHẨM TỪ API
// =====================================================
async function loadProducts(category = "new") {
    const res = await fetch(`/api/products/category/${category}`);
    const list = await res.json();

    renderProducts(list);
}

function renderProducts(products) {
    const grid = document.querySelector("#tab-new");
    grid.innerHTML = "";

    products.forEach(p => {
        grid.innerHTML += `
        <div class="product-item">
            <img src="${p.image}">
            <p class="product-title">${p.title}</p>
            <p class="product-price-old">${p.priceOld.toLocaleString()}₫</p>
            <p class="product-price-new">${p.priceNew.toLocaleString()}₫</p>
            <div class="product-actions">
                <button onclick="addToCart(${p.id})">Add to cart</button>
                <button onclick="gotoDetail(${p.id})">Details</button>
            </div>
        </div>
        `;
    });
}

// =====================================================
// 3) ADD TO CART
// =====================================================
async function addToCart(id) {
    await fetch("/api/cart/add", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ id, qty: 1 })
    });
    alert("Đã thêm vào giỏ hàng!");
}

function gotoDetail(id) {
    window.location.href = `/product.html?id=${id}`;
}

// =====================================================
// 4) CATEGORY CLICK (SIDEBAR)
// =====================================================
function setupCategoryClick() {
    document.querySelectorAll(".sidebar-menu a").forEach(a => {
        a.addEventListener("click", async () => {
            const cat = a.innerText.trim().toLowerCase().replace(/ /g, "");

            // Lưu lại category user vừa xem
            fetch("/api/user/category", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({ category: cat })
            });

            loadProducts(cat);
        });
    });
}

// =====================================================
// 5) SEARCH
// =====================================================
function setupSearch() {
    document.querySelector(".search button").addEventListener("click", async () => {
        let q = document.querySelector(".search input").value;

        const res = await fetch(`/api/search?q=${q}`);
        const list = await res.json();

        renderProducts(list);
    });
}

// =====================================================
// 6) TAB SẢN PHẨM (HOT NEW / PROMO…)
// =====================================================
function setupTabs() {
    const links = document.querySelectorAll(".product-tabs a");
    const panes = document.querySelectorAll(".tab-pane");

    links.forEach(link => {
        link.addEventListener("click", e => {
            e.preventDefault();

            links.forEach(l => l.classList.remove("active"));
            link.classList.add("active");

            const tab = link.dataset.tab;

            panes.forEach(p => p.classList.remove("active"));
            document.getElementById(`tab-${tab}`).classList.add("active");

            if (tab === "new") loadProducts("new");
            if (tab === "promo") loadProducts("economy"); // ví dụ: dùng category khác
        });
    });
}

// =====================================================
// 7) SLIDER BANNER (CAROUSEL TỐI ƯU HƠN)
// =====================================================
function setupCarousel() {
    const wrapper = document.querySelector('.slide-wrapper');
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');

    if (!wrapper || slides.length <= 2) return;

    const total = slides.length;
    const realTotal = total - 2;

    let index = 1;
    let timer;

    function go(i, smooth = true) {
        wrapper.style.transition = smooth ? 'transform 0.8s ease-in-out' : 'none';
        index = i;

        wrapper.style.transform = `translateX(${-index * (100 / total)}%)`;

        // Loop mượt
        if (index === total - 1)
            setTimeout(() => go(1, false), 800);

        if (index === 0)
            setTimeout(() => go(realTotal, false), 800);
    }

    function auto() {
        clearInterval(timer);
        timer = setInterval(() => go(index + 1), 4000);
    }

    nextBtn.onclick = () => { clearInterval(timer); go(index + 1); auto(); }
    prevBtn.onclick = () => { clearInterval(timer); go(index - 1); auto(); }

    go(1, false);
    auto();
}

// =====================================================
// 8) SUGGEST SẢN PHẨM (User đã xem gần đây)
// =====================================================
async function loadSuggest() {
    const res = await fetch("/api/suggest");
    const list = await res.json();

    if (list.length === 0) return;

    const box = document.createElement("div");
    box.innerHTML = "<h3>Sản phẩm bạn đã xem</h3>";

    list.forEach(p => {
        box.innerHTML += `
            <p onclick="gotoDetail(${p.id})" style="cursor:pointer;">
            ${p.title} – ${p.priceNew.toLocaleString()}₫</p>`;
    });

    document.querySelector(".content").appendChild(box);
}

// =====================================================
// KHỞI TẠO TOÀN BỘ SAU KHI TẢI TRANG
// =====================================================
document.addEventListener("DOMContentLoaded", () => {
    loadUser();          // Thông tin user
    loadProducts();      // Load sản phẩm mặc định
    setupCategoryClick();
    setupSearch();
    setupTabs();
    setupCarousel();
    loadSuggest();
});

// =====================================================
// 1. RENDER 1 PRODUCT ITEM
// =====================================================
function productHTML(p) {
    return `
        <div class="product-item">
            <img src="${p.image}">
            <p class="product-title">${p.title}</p>
            <p class="product-price-old">${p.priceOld.toLocaleString()}₫</p>
            <p class="product-price-new">${p.priceNew.toLocaleString()}₫</p>
            <div class="product-actions">
                <button onclick="addToCart(${p.id})">Add to cart</button>
                <button class="buy-now"><a href="#">Buy Now</a></button>
            </div>
        </div>
    `;
}

// =====================================================
// 2. LOAD PRODUCT BY CATEGORY INTO A SECTION
// =====================================================
async function loadSection(category, elementId) {
    const res = await fetch(`/api/products/category/${category}`);
    const data = await res.json();

    const box = document.getElementById(elementId);
    if (!box) return;

    box.innerHTML = "";

    data.forEach(p => {
        box.innerHTML += productHTML(p);
    });
}

// =====================================================
// 3. ADD TO CART
// =====================================================
async function addToCart(id) {
    await fetch("/api/cart/add", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ id, qty: 1 })
    });

    alert("Đã thêm vào giỏ hàng!");
}

// =====================================================
// 4. LOAD ALL SECTIONS DYNAMIC
// =====================================================
document.addEventListener("DOMContentLoaded", () => {

    // Hot New Books
    loadSection("new", "tab-new");

    // Promo (hiện database bạn CHƯA có promo, sẽ trống)
    loadSection("promo", "tab-promo");

    // Sách Văn Học
    loadSection("literature", "literature-section");

    // Sách Tâm Lý (chưa có dữ liệu → sẽ trống)
    loadSection("psychology", "psychology-section");

    // Có thể mở rộng thêm nhiều section:
    // loadSection("kids", "kids-section");
    // loadSection("foreign", "foreign-section");
});

async function loadUserInfo() {
    const res = await fetch("/api/check-login");
    const data = await res.json();

    if (!data.loggedIn) {
        // chưa login thì giữ nút login, register
        return;
    }

    const user = data.user;

    document.querySelector(".account").innerHTML = `
        <span class="user-name">${user.name}</span>
        <img src="${user.avatar || 'default-avatar.png'}" 
             class="user-avatar"
             style="width:35px;height:35px;border-radius:50%;margin-left:10px;">
        <a id="logoutBtn" href="#" style="margin-left:10px;color:red;">Logout</a>
    `;
}

document.addEventListener("DOMContentLoaded", loadUserInfo);

document.addEventListener("click", async (e) => {
    if (e.target.id === "logoutBtn") {
        e.preventDefault();

        if (!confirm("Bạn có chắc chắn muốn đăng xuất không?")) return;

        const res = await fetch("/api/logout");
        const data = await res.json();

        if (data.success) {
            alert("Đăng xuất thành công!");
            window.location.href = "/login.html";
        }
    }
});