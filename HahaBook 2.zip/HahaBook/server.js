const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");
const cors = require("cors");
const session = require("express-session");

const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth20").Strategy;

const app = express();
const PORT = 3000;

/* ============================================================
   SESSION + PASSPORT CONFIG
============================================================ */
app.use(session({
  secret: "hahabook_secret_key",
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 1000 * 60 * 30 }
}));
app.use(passport.initialize());
app.use(passport.session());

// serialize
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

/* ============================================================
   GOOGLE AUTH
============================================================ */
passport.use(
  new GoogleStrategy(
    {
      clientID:
        "342577786043-0tib7anmugc80g8lteockrvhkff7mbd3.apps.googleusercontent.com",
      clientSecret: "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",
      callbackURL: "http://localhost:3000/auth/google/callback",
    },
    (accessToken, refreshToken, profile, done) => {
      const user = {
        name: profile.displayName,
        email: profile.emails[0].value,
        avatar: profile.photos[0].value,
      };
      done(null, user);
    }
  )
);

/* ============================================================
   MIDDLEWARE
============================================================ */
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

/* ============================================================
   JSON DATABASE ACCESS (FIXED)
============================================================ */
function getUsers() {
  return JSON.parse(fs.readFileSync(path.join(__dirname, "users.json"), "utf-8"));
}

function saveUsers(users) {
  fs.writeFileSync(path.join(__dirname, "users.json"), JSON.stringify(users, null, 2));
}

function getDB() {
  return JSON.parse(fs.readFileSync(path.join(__dirname, "database.json"), "utf-8"));
}

/* ============================================================
   AUTH: LOGIN / REGISTER
============================================================ */
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  let users = getUsers();
  const user = users.find((u) => u.email === email && u.password === password);

  if (user) {
    req.session.user = { name: user.name, email: user.email };
    return res.json({ success: true, name: user.name });
  }
  res.json({ success: false, message: "Sai email hoặc mật khẩu!" });
});

app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;

  let users = getUsers();
  if (users.find((u) => u.email === email))
    return res.json({ success: false, message: "Email đã tồn tại!" });

  users.push({
    name,
    email,
    password,
    cart: [],
    history: [],
    lastCategory: "",
  });

  saveUsers(users);
  res.json({ success: true });
});

// Check login
app.get("/api/check-login", (req, res) => {
  if (req.session.user) res.json({ loggedIn: true, user: req.session.user });
  else res.json({ loggedIn: false });
});

// Logout
app.get("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});

/* ============================================================
   GOOGLE LOGIN ROUTES
============================================================ */
app.get(
  "/auth/google",
  passport.authenticate("google", { scope: ["profile", "email"] })
);

app.get(
  "/auth/google/callback",
  passport.authenticate("google", { failureRedirect: "/login.html" }),
  (req, res) => {
    let users = getUsers();
    let googleUser = req.user;

    // Nếu user Google chưa tồn tại → tạo mới
    let exist = users.find((u) => u.email === googleUser.email);

    if (!exist) {
      users.push({
        name: googleUser.name,
        email: googleUser.email,
        avatar: googleUser.avatar,
        cart: [],
        history: [],
        lastCategory: "",
      });
      saveUsers(users);
    }

    req.session.user = googleUser;
    res.redirect("/home");
  }
);

/* ============================================================
   USER INFO API
============================================================ */
app.get("/api/user/info", (req, res) => {
  if (!req.session.user) return res.json({ loggedIn: false });

  const users = getUsers();
  const user = users.find((u) => u.email === req.session.user.email);

  res.json({
    name: user.name,
    email: user.email,
    avatar: user.avatar || "",
    cart: user.cart || [],
    history: user.history || [],
    lastCategory: user.lastCategory || "",
  });
});

/* ============================================================
   CART API
============================================================ */
app.get("/api/cart", (req, res) => {
  if (!req.session.user)
    return res.status(401).json({ message: "Chưa đăng nhập" });

  const users = getUsers();
  const user = users.find((u) => u.email === req.session.user.email);

  res.json(user.cart || []);
});

app.post("/api/cart/add", (req, res) => {
  if (!req.session.user)
    return res.status(401).json({ message: "Chưa đăng nhập" });

  const { id, qty } = req.body;

  let users = getUsers();
  const index = users.findIndex((u) => u.email === req.session.user.email);

  let cart = users[index].cart || [];
  let existing = cart.find((p) => p.id === id);

  if (existing) existing.qty += qty;
  else cart.push({ id, qty });

  users[index].cart = cart;
  saveUsers(users);

  res.json({ success: true, cart });
});

app.post("/api/cart/remove", (req, res) => {
  if (!req.session.user)
    return res.status(401).json({ message: "Chưa đăng nhập" });

  const { id } = req.body;

  let users = getUsers();
  const index = users.findIndex((u) => u.email === req.session.user.email);

  users[index].cart = users[index].cart.filter((p) => p.id !== id);
  saveUsers(users);

  res.json({ success: true });
});

/* ============================================================
   CATEGORY + VIEW HISTORY API
============================================================ */
app.post("/api/user/category", (req, res) => {
  if (!req.session.user)
    return res.status(401).json({ message: "Chưa đăng nhập" });

  const { category } = req.body;

  let users = getUsers();
  let index = users.findIndex((u) => u.email === req.session.user.email);

  users[index].lastCategory = category;
  saveUsers(users);

  res.json({ success: true });
});

app.post("/api/user/viewed", (req, res) => {
  if (!req.session.user)
    return res.status(401).json({ message: "Chưa đăng nhập" });

  const { productId } = req.body;

  let users = getUsers();
  let index = users.findIndex((u) => u.email === req.session.user.email);

  let history = users[index].history || [];
  if (!history.includes(productId)) history.push(productId);

  users[index].history = history;
  saveUsers(users);

  res.json({ success: true });
});

/* ============================================================
   PRODUCT API (FINAL + CLEAN)
============================================================ */

// Lấy sản phẩm theo category
app.get("/api/products/category/:cat", (req, res) => {
  const db = getDB();
  const cat = req.params.cat;
  const result = db.products.filter((p) => p.category === cat);
  res.json(result);
});

// Lấy toàn bộ sản phẩm
app.get("/api/products", (req, res) => {
  const db = getDB();
  res.json(db.products);
});

// Lấy chi tiết 1 sản phẩm
app.get("/api/product/:id", (req, res) => {
  const db = getDB();
  const id = Number(req.params.id);
  const product = db.products.find((p) => p.id === id);
  if (!product) return res.status(404).json({ message: "Product not found" });
  res.json(product);
});

/* ============================================================
   PROTECT HOME PAGE
============================================================ */
app.get("/home", (req, res) => {
  if (!req.session.user) return res.redirect("/login.html");
  res.sendFile(path.join(__dirname, "public", "home.html"));
});

/* ============================================================
   START SERVER
============================================================ */
app.listen(PORT, () =>
  console.log(`🔥 Server chạy tại http://localhost:${PORT}`)
);
